document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Form validation for login and signup forms
    const forms = document.querySelectorAll('.needs-validation');
    
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            
            form.classList.add('was-validated');
        }, false);
    });
    
    // Password validation in signup form
    const passwordField = document.getElementById('password');
    const confirmPasswordField = document.getElementById('confirm_password');
    
    if (passwordField && confirmPasswordField) {
        // Get the password requirement list items
        const lengthCheck = document.getElementById('length-check');
        const uppercaseCheck = document.getElementById('uppercase-check');
        const numberCheck = document.getElementById('number-check');
        const specialCheck = document.getElementById('special-check');
        
        // Function to update password validation visual feedback
        function updatePasswordRequirements(password) {
            // Check each requirement
            const hasLength = password.length >= 8;
            const hasUpperCase = /[A-Z]/.test(password);
            const hasNumber = /[0-9]/.test(password);
            const hasSpecial = /[@$!%*?&]/.test(password);
            
            // Update the visual UI
            if (lengthCheck) {
                lengthCheck.className = hasLength ? 'text-success' : '';
                lengthCheck.innerHTML = hasLength ? 
                    '<i class="fas fa-check"></i> At least 8 characters' : 
                    'At least 8 characters';
            }
            
            if (uppercaseCheck) {
                uppercaseCheck.className = hasUpperCase ? 'text-success' : '';
                uppercaseCheck.innerHTML = hasUpperCase ? 
                    '<i class="fas fa-check"></i> At least 1 uppercase letter' : 
                    'At least 1 uppercase letter';
            }
            
            if (numberCheck) {
                numberCheck.className = hasNumber ? 'text-success' : '';
                numberCheck.innerHTML = hasNumber ? 
                    '<i class="fas fa-check"></i> At least 1 number' : 
                    'At least 1 number';
            }
            
            if (specialCheck) {
                specialCheck.className = hasSpecial ? 'text-success' : '';
                specialCheck.innerHTML = hasSpecial ? 
                    '<i class="fas fa-check"></i> At least 1 special character' : 
                    'At least 1 special character';
            }
            
            // Return true if all requirements are met
            return hasLength && hasUpperCase && hasNumber && hasSpecial;
        }
        
        confirmPasswordField.addEventListener('input', function() {
            if (passwordField.value !== confirmPasswordField.value) {
                confirmPasswordField.setCustomValidity("Passwords do not match");
            } else {
                confirmPasswordField.setCustomValidity("");
            }
        });
        
        passwordField.addEventListener('input', function() {
            // Password validation regex
            const passwordRegex = /^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
            
            // Update the visual validation requirements
            const requirementsMet = updatePasswordRequirements(passwordField.value);
            
            if (!passwordRegex.test(passwordField.value)) {
                passwordField.setCustomValidity("Password must be at least 8 characters long and contain at least one uppercase letter, one number, and one special character");
            } else {
                passwordField.setCustomValidity("");
                
                // Check if confirm password matches
                if (confirmPasswordField.value) {
                    if (passwordField.value !== confirmPasswordField.value) {
                        confirmPasswordField.setCustomValidity("Passwords do not match");
                    } else {
                        confirmPasswordField.setCustomValidity("");
                    }
                }
            }
        });
    }
    
    // Add smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });
    
    // Initialize any date pickers
    const datePickers = document.querySelectorAll('.datepicker');
    if (datePickers.length > 0) {
        datePickers.forEach(el => {
            new Datepicker(el, {
                format: 'yyyy-mm-dd',
                autohide: true
            });
        });
    }
});
