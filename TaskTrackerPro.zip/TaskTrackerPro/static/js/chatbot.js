document.addEventListener('DOMContentLoaded', function() {
    const chatContainer = document.querySelector('.chat-container');
    const chatMessages = document.querySelector('.chat-messages');
    const userInput = document.getElementById('user-input');
    const sendButton = document.getElementById('send-button');
    const startChatButton = document.getElementById('start-chat-button');
    
    let sessionId = null;
    let awaitingResponse = false;
    
    // Initialize the chat
    function startChat() {
        if (startChatButton) {
            startChatButton.disabled = true;
            startChatButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Starting...';
        }
        
        fetch('/api/chat/start', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            }
        })
        .then(response => response.json())
        .then(data => {
            sessionId = data.session_id;
            
            // Enable chat UI
            if (chatContainer) {
                chatContainer.classList.remove('d-none');
            }
            
            // Add bot's greeting message
            addMessage(data.message, 'bot');
            
            if (startChatButton) {
                startChatButton.classList.add('d-none');
            }
        })
        .catch(error => {
            console.error('Error starting chat:', error);
            if (startChatButton) {
                startChatButton.disabled = false;
                startChatButton.textContent = 'Start Chat';
            }
        });
    }
    
    // Add a message to the chat
    function addMessage(message, sender) {
        const messageElement = document.createElement('div');
        messageElement.classList.add('message', `${sender}-message`);
        
        // If the message is an object with HTML, use it directly
        if (typeof message === 'object' && message.html) {
            messageElement.innerHTML = message.html;
        } else {
            messageElement.textContent = message;
        }
        
        chatMessages.appendChild(messageElement);
        
        // Scroll to the bottom of the chat
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    // Send a message to the server
    function sendMessage() {
        const message = userInput.value.trim();
        
        if (!message || !sessionId || awaitingResponse) {
            return;
        }
        
        // Add user message to chat
        addMessage(message, 'user');
        
        // Clear input
        userInput.value = '';
        
        // Set awaiting response flag
        awaitingResponse = true;
        
        // Add typing indicator
        const typingIndicator = document.createElement('div');
        typingIndicator.classList.add('message', 'bot-message', 'typing-indicator');
        typingIndicator.innerHTML = '<span></span><span></span><span></span>';
        chatMessages.appendChild(typingIndicator);
        chatMessages.scrollTop = chatMessages.scrollHeight;
        
        // Send message to server
        fetch('/api/chat/message', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                session_id: sessionId,
                message: message
            })
        })
        .then(response => response.json())
        .then(data => {
            // Remove typing indicator
            const typingIndicator = document.querySelector('.typing-indicator');
            if (typingIndicator) {
                typingIndicator.remove();
            }
            
            // Add bot response to chat
            if (data.message) {
                addMessage(data.message, 'bot');
            }
            
            // Check if a booking was completed
            if (data.booking_id) {
                // Add download ticket button
                const ticketButton = document.createElement('div');
                ticketButton.classList.add('message', 'bot-message', 'ticket-button');
                ticketButton.innerHTML = `
                    <a href="/ticket/${data.booking_id}" target="_blank" class="btn btn-success">
                        <i class="fas fa-ticket-alt"></i> Download Ticket
                    </a>
                `;
                chatMessages.appendChild(ticketButton);
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }
            
            // Reset awaiting response flag
            awaitingResponse = false;
        })
        .catch(error => {
            console.error('Error sending message:', error);
            
            // Remove typing indicator
            const typingIndicator = document.querySelector('.typing-indicator');
            if (typingIndicator) {
                typingIndicator.remove();
            }
            
            // Add error message
            addMessage('Sorry, there was an error processing your request. Please try again.', 'bot');
            
            // Reset awaiting response flag
            awaitingResponse = false;
        });
    }
    
    // Event listeners
    if (startChatButton) {
        startChatButton.addEventListener('click', startChat);
    }
    
    if (sendButton) {
        sendButton.addEventListener('click', sendMessage);
    }
    
    if (userInput) {
        userInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                sendMessage();
            }
        });
    }
    
    // Start chat automatically if on dashboard page
    if (window.location.pathname === '/dashboard' && startChatButton) {
        startChat();
    }
});
