import os
import uuid
import json
import logging
from datetime import datetime
from flask import render_template, request, redirect, url_for, flash, jsonify, session
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash

from app import app, db
from models import User, Booking, ChatSession
from utils.nlp_processing import process_user_input
from utils.aviation_api import get_flights, get_airports
from utils.ticket_generator import generate_ticket

# Configure Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"

@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        user = User.query.filter_by(email=email).first()
        
        if user and user.check_password(password):
            login_user(user)
            next_page = request.args.get('next')
            return redirect(next_page or url_for('dashboard'))
        else:
            flash('Invalid email or password')
    
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        first_name = request.form.get('first_name')
        last_name = request.form.get('last_name')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        if not all([first_name, last_name, email, password, confirm_password]):
            flash('All fields are required')
            return render_template('signup.html')
        
        if password != confirm_password:
            flash('Passwords do not match')
            return render_template('signup.html')
        
        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            flash('Email already registered')
            return render_template('signup.html')
        
        user = User(
            first_name=first_name,
            last_name=last_name,
            email=email
        )
        user.set_password(password)
        
        db.session.add(user)
        db.session.commit()
        
        flash('Account created successfully! Please log in.')
        return redirect(url_for('login'))
    
    return render_template('signup.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.')
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    # Get user's bookings
    bookings = Booking.query.filter_by(user_id=current_user.id).order_by(Booking.created_at.desc()).all()
    return render_template('dashboard.html', bookings=bookings)

@app.route('/ticket/<booking_id>')
@login_required
def ticket(booking_id):
    booking = Booking.query.filter_by(id=booking_id, user_id=current_user.id).first_or_404()
    return render_template('ticket.html', booking=booking)

# Chat API
@app.route('/api/chat/start', methods=['POST'])
@login_required
def start_chat():
    session_id = str(uuid.uuid4())
    
    chat_session = ChatSession(
        user_id=current_user.id,
        session_id=session_id,
        state="greeting",
        data={}
    )
    
    db.session.add(chat_session)
    db.session.commit()
    
    return jsonify({
        "session_id": session_id,
        "message": "Welcome to SkyBot! Ready to book your flight?"
    })

@app.route('/api/chat/message', methods=['POST'])
@login_required
def chat_message():
    data = request.json
    session_id = data.get('session_id')
    user_message = data.get('message', '').strip()
    
    if not session_id or not user_message:
        return jsonify({"error": "Missing required parameters"}), 400
    
    chat_session = ChatSession.query.filter_by(session_id=session_id).first()
    if not chat_session:
        return jsonify({"error": "Invalid session"}), 404
    
    # Process user input and get response based on current state
    current_state = chat_session.state
    session_data = chat_session.data if chat_session.data else {}
    
    # Process the message with NLP
    response, new_state, updated_data = process_user_input(
        user_message, 
        current_state, 
        session_data
    )
    
    # Update session state and data
    chat_session.state = new_state
    chat_session.data = updated_data
    db.session.commit()
    
    # If booking is complete, create a booking record
    if new_state == "booking_complete" and updated_data.get('confirmed'):
        try:
            # Generate a unique booking reference
            booking_ref = f"SKY{uuid.uuid4().hex[:6].upper()}"
            
            # Convert the ISO departure time to a datetime object
            departure_time_dt = datetime.fromisoformat(updated_data.get('departure_time'))
            arrival_time_dt = datetime.fromisoformat(updated_data.get('arrival_time'))
            
            # If travel_date is provided, adjust departure and arrival times to that date
            if updated_data.get('travel_date'):
                try:
                    # Parse the travel date
                    travel_date = datetime.strptime(updated_data.get('travel_date'), "%Y-%m-%d")
                    
                    # Adjust departure time to keep only the time component from original but use the date from travel_date
                    departure_time_dt = departure_time_dt.replace(
                        year=travel_date.year,
                        month=travel_date.month,
                        day=travel_date.day
                    )
                    
                    # Calculate the duration between departure and arrival
                    duration = arrival_time_dt - datetime.fromisoformat(updated_data.get('departure_time'))
                    
                    # Add the duration to the new departure time to get the new arrival time
                    arrival_time_dt = departure_time_dt + duration
                    
                    logging.info(f"Adjusted flight times to match travel date {updated_data.get('travel_date')}")
                except Exception as e:
                    logging.error(f"Failed to adjust flight times: {e}")
            
            # Create the booking
            booking = Booking(
                user_id=current_user.id,
                airline=updated_data.get('airline'),
                flight_number=updated_data.get('flight_number'),
                departure_city=updated_data.get('departure_city'),
                departure_iata=updated_data.get('departure_iata'),
                destination_city=updated_data.get('destination_city'),
                destination_iata=updated_data.get('destination_iata'),
                travel_date=updated_data.get('travel_date'),
                departure_time=departure_time_dt,
                arrival_time=arrival_time_dt,
                passenger_age=updated_data.get('age'),
                travel_class=updated_data.get('travel_class'),
                price=updated_data.get('price'),
                booking_reference=booking_ref,
                seat_number=updated_data.get('seat_number'),
                status="Confirmed"
            )
            
            db.session.add(booking)
            db.session.commit()
            
            # Add booking ID to response for ticket download
            response["booking_id"] = booking.id
            
        except Exception as e:
            logging.error(f"Error creating booking: {e}")
            response["message"] = "There was an error processing your booking. Please try again."
    
    return jsonify(response)

# API routes for flight search
@app.route('/api/flights', methods=['GET'])
@login_required
def search_flights():
    departure = request.args.get('departure')
    destination = request.args.get('destination')
    
    if not departure or not destination:
        return jsonify({"error": "Missing required parameters"}), 400
    
    try:
        flights = get_flights(departure, destination)
        return jsonify(flights)
    except Exception as e:
        logging.error(f"Error fetching flights: {e}")
        return jsonify({"error": "Could not fetch flight information"}), 500

@app.route('/api/airports', methods=['GET'])
@login_required
def airports_api():
    try:
        airports = get_airports()
        return jsonify(airports)
    except Exception as e:
        logging.error(f"Error fetching airports: {e}")
        return jsonify({"error": "Could not fetch airport information"}), 500

# Error handlers
@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def server_error(e):
    return render_template('500.html'), 500
