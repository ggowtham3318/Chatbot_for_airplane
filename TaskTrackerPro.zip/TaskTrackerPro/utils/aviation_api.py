import os
import requests
import logging
import json
from datetime import datetime, timedelta
import random

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# AviationStack API Key
API_KEY = os.environ.get("AVIATION_API_KEY", "")

# Base URL for AviationStack API
BASE_URL = "http://api.aviationstack.com/v1"

# Cache for API responses to reduce calls
flights_cache = {}
airports_cache = None

# IATA codes of Indian airports
INDIAN_AIRPORTS = [
    "DEL", "BOM", "BLR", "HYD", "MAA", "CCU", "COK", "PNQ", "AMD", "GOI", 
    "JAI", "LKO", "IXC", "GAU", "PAT", "IXB", "TRV", "SXR", "BBI", "IXR", 
    "IXZ", "VTZ", "ATQ", "IDR", "IXA", "IXM", "IXL", "RPR"
]

def get_flights(departure_iata, arrival_iata):
    """
    Fetch flights between two airports using AviationStack API
    
    Args:
        departure_iata (str): Departure airport IATA code
        arrival_iata (str): Arrival airport IATA code
        
    Returns:
        dict: Flight data response
    """
    # Check cache first
    cache_key = f"{departure_iata}-{arrival_iata}"
    cache_timestamp = flights_cache.get(cache_key, {}).get("timestamp")
    
    # If we have cached data less than 30 minutes old, return it
    if cache_timestamp and (datetime.now() - cache_timestamp).total_seconds() < 1800:
        logging.info(f"Using cached flight data for {cache_key}")
        return flights_cache[cache_key]["data"]
    
    if not API_KEY:
        logging.warning("No AviationStack API key provided. Using mock flight data.")
        return get_mock_flights(departure_iata, arrival_iata)
    
    try:
        # Make API request
        url = f"{BASE_URL}/flights"
        params = {
            "access_key": API_KEY,
            "dep_iata": departure_iata,
            "arr_iata": arrival_iata,
            "limit": 5
        }
        
        logging.info(f"Fetching flights from {departure_iata} to {arrival_iata}")
        response = requests.get(url, params=params)
        
        if response.status_code == 200:
            data = response.json()
            
            # Cache the response
            flights_cache[cache_key] = {
                "timestamp": datetime.now(),
                "data": data
            }
            
            return data
        else:
            logging.error(f"API error: {response.status_code} - {response.text}")
            return get_mock_flights(departure_iata, arrival_iata)
        
    except Exception as e:
        logging.error(f"Error fetching flights: {str(e)}")
        return get_mock_flights(departure_iata, arrival_iata)

def get_airports():
    """
    Fetch list of airports using AviationStack API
    
    Returns:
        list: Airport data
    """
    global airports_cache
    
    # Return cached data if available
    if airports_cache:
        return airports_cache
    
    if not API_KEY:
        logging.warning("No AviationStack API key provided. Using mock airport data.")
        return get_mock_airports()
    
    try:
        # Make API request
        url = f"{BASE_URL}/airports"
        params = {
            "access_key": API_KEY,
            "limit": 100
        }
        
        logging.info("Fetching airports list")
        response = requests.get(url, params=params)
        
        if response.status_code == 200:
            data = response.json()
            
            # Filter to only include Indian airports
            indian_airports = [airport for airport in data.get("data", []) 
                              if airport.get("country_code") == "IN"]
            
            # Cache the filtered response
            airports_cache = indian_airports
            
            return indian_airports
        else:
            logging.error(f"API error: {response.status_code} - {response.text}")
            return get_mock_airports()
        
    except Exception as e:
        logging.error(f"Error fetching airports: {str(e)}")
        return get_mock_airports()

def get_airport_by_name(name):
    """
    Find an airport by name or city
    
    Args:
        name (str): Airport name or city
        
    Returns:
        dict: Airport data or None if not found
    """
    # Get the list of airports
    airports = get_airports()
    
    # Convert the search name to lowercase for case-insensitive matching
    name = name.lower()
    
    # First try exact matches
    for airport in airports:
        if (airport.get("airport_name", "").lower() == name or 
            airport.get("city", "").lower() == name or
            airport.get("iata_code", "").lower() == name):
            return {
                "name": airport.get("airport_name"),
                "city": airport.get("city"),
                "iata": airport.get("iata_code")
            }
    
    # Then try partial matches
    for airport in airports:
        if (name in airport.get("airport_name", "").lower() or 
            name in airport.get("city", "").lower()):
            return {
                "name": airport.get("airport_name"),
                "city": airport.get("city"),
                "iata": airport.get("iata_code")
            }
    
    return None

def get_mock_flights(departure_iata, arrival_iata):
    """
    Generate mock flight data for testing
    
    Args:
        departure_iata (str): Departure airport IATA code
        arrival_iata (str): Arrival airport IATA code
        
    Returns:
        dict: Mock flight data
    """
    # Airlines operating in India
    airlines = [
        {"name": "IndiGo", "iata": "6E"},
        {"name": "Air India", "iata": "AI"},
        {"name": "SpiceJet", "iata": "SG"},
        {"name": "GoAir", "iata": "G8"},
        {"name": "Vistara", "iata": "UK"},
        {"name": "AirAsia India", "iata": "I5"}
    ]
    
    # Generate 1-3 mock flights
    num_flights = random.randint(1, 3)
    flights = []
    
    for _ in range(num_flights):
        # Pick a random airline
        airline = random.choice(airlines)
        
        # Generate a flight number
        flight_number = f"{airline['iata']}-{random.randint(100, 999)}"
        
        # Generate departure and arrival times
        now = datetime.now()
        dep_date = now + timedelta(days=random.randint(1, 30))
        dep_hour = random.randint(6, 22)
        dep_minute = random.choice([0, 15, 30, 45])
        dep_time = dep_date.replace(hour=dep_hour, minute=dep_minute, second=0, microsecond=0)
        
        # Flight duration between 1-3 hours for domestic Indian flights
        duration = timedelta(hours=random.randint(1, 3), minutes=random.randint(0, 59))
        arr_time = dep_time + duration
        
        # Format times as ISO strings
        dep_time_str = dep_time.strftime("%Y-%m-%dT%H:%M:%SZ")
        arr_time_str = arr_time.strftime("%Y-%m-%dT%H:%M:%SZ")
        
        flight = {
            "flight": {
                "iata": flight_number,
                "icao": None,
                "number": flight_number.split("-")[1]
            },
            "departure": {
                "airport": get_airport_name(departure_iata),
                "timezone": "Asia/Kolkata",
                "iata": departure_iata,
                "icao": None,
                "scheduled": dep_time_str,
                "estimated": dep_time_str,
                "actual": None,
                "terminal": str(random.randint(1, 3)),
                "gate": f"{random.choice('ABCDE')}{random.randint(1, 20)}"
            },
            "arrival": {
                "airport": get_airport_name(arrival_iata),
                "timezone": "Asia/Kolkata",
                "iata": arrival_iata,
                "icao": None,
                "scheduled": arr_time_str,
                "estimated": arr_time_str,
                "actual": None,
                "terminal": str(random.randint(1, 3)),
                "gate": f"{random.choice('ABCDE')}{random.randint(1, 20)}"
            },
            "airline": {
                "name": airline["name"],
                "iata": airline["iata"],
                "icao": None
            },
            "flight_status": "scheduled"
        }
        
        flights.append(flight)
    
    return {
        "pagination": {
            "limit": 100,
            "offset": 0,
            "count": len(flights),
            "total": len(flights)
        },
        "data": flights
    }

def get_mock_airports():
    """
    Generate mock airport data for Indian airports
    
    Returns:
        list: Mock airport data
    """
    indian_airports = [
        {"airport_name": "Indira Gandhi International Airport", "city": "New Delhi", "iata_code": "DEL", "country_code": "IN"},
        {"airport_name": "Chhatrapati Shivaji Maharaj International Airport", "city": "Mumbai", "iata_code": "BOM", "country_code": "IN"},
        {"airport_name": "Kempegowda International Airport", "city": "Bangalore", "iata_code": "BLR", "country_code": "IN"},
        {"airport_name": "Rajiv Gandhi International Airport", "city": "Hyderabad", "iata_code": "HYD", "country_code": "IN"},
        {"airport_name": "Chennai International Airport", "city": "Chennai", "iata_code": "MAA", "country_code": "IN"},
        {"airport_name": "Netaji Subhas Chandra Bose International Airport", "city": "Kolkata", "iata_code": "CCU", "country_code": "IN"},
        {"airport_name": "Cochin International Airport", "city": "Kochi", "iata_code": "COK", "country_code": "IN"},
        {"airport_name": "Pune Airport", "city": "Pune", "iata_code": "PNQ", "country_code": "IN"},
        {"airport_name": "Sardar Vallabhbhai Patel International Airport", "city": "Ahmedabad", "iata_code": "AMD", "country_code": "IN"},
        {"airport_name": "Goa International Airport", "city": "Goa", "iata_code": "GOI", "country_code": "IN"},
        {"airport_name": "Jaipur International Airport", "city": "Jaipur", "iata_code": "JAI", "country_code": "IN"},
        {"airport_name": "Lucknow Airport", "city": "Lucknow", "iata_code": "LKO", "country_code": "IN"}
    ]
    
    return indian_airports

def get_airport_name(iata_code):
    """
    Get airport name from IATA code
    
    Args:
        iata_code (str): IATA code
        
    Returns:
        str: Airport name
    """
    airport_names = {
        "DEL": "Indira Gandhi International Airport",
        "BOM": "Chhatrapati Shivaji Maharaj International Airport",
        "BLR": "Kempegowda International Airport",
        "HYD": "Rajiv Gandhi International Airport",
        "MAA": "Chennai International Airport",
        "CCU": "Netaji Subhas Chandra Bose International Airport",
        "COK": "Cochin International Airport",
        "PNQ": "Pune Airport",
        "AMD": "Sardar Vallabhbhai Patel International Airport",
        "GOI": "Goa International Airport",
        "JAI": "Jaipur International Airport",
        "LKO": "Lucknow Airport"
    }
    
    return airport_names.get(iata_code, f"{iata_code} Airport")
