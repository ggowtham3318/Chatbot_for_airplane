import re
import json
import random
from datetime import datetime, timedelta
import logging
from utils.aviation_api import get_flights, get_airport_by_name

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Define common airports in India
INDIAN_AIRPORTS = {
    "DEL": {"name": "Delhi", "city": "New Delhi", "full_name": "Indira Gandhi International Airport"},
    "BOM": {"name": "Mumbai", "city": "Mumbai", "full_name": "Chhatrapati Shivaji Maharaj International Airport"},
    "BLR": {"name": "Bangalore", "city": "Bangalore", "full_name": "Kempegowda International Airport"},
    "HYD": {"name": "Hyderabad", "city": "Hyderabad", "full_name": "Rajiv Gandhi International Airport"},
    "MAA": {"name": "Chennai", "city": "Chennai", "full_name": "Chennai International Airport"},
    "CCU": {"name": "Kolkata", "city": "Kolkata", "full_name": "Netaji Subhas Chandra Bose International Airport"},
    "COK": {"name": "Kochi", "city": "Kochi", "full_name": "Cochin International Airport"},
    "PNQ": {"name": "Pune", "city": "Pune", "full_name": "Pune Airport"},
    "AMD": {"name": "Ahmedabad", "city": "Ahmedabad", "full_name": "Sardar Vallabhbhai Patel International Airport"},
    "GOI": {"name": "Goa", "city": "Goa", "full_name": "Goa International Airport"}
}

# Define common airlines
AIRLINES = {
    "indigo": {"name": "IndiGo", "code": "6E"},
    "air india": {"name": "Air India", "code": "AI"},
    "spicejet": {"name": "SpiceJet", "code": "SG"},
    "go air": {"name": "Go Air", "code": "G8"},
    "vistara": {"name": "Vistara", "code": "UK"},
    "air asia": {"name": "Air Asia", "code": "I5"}
}

# Define state transitions
STATE_TRANSITIONS = {
    "greeting": "airline",
    "airline": "departure",
    "departure": "destination",
    "destination": "date",
    "date": "age",
    "age": "travel_class",
    "travel_class": "search_flights",
    "search_flights": "confirm_booking",
    "confirm_booking": "booking_complete"
}

def extract_airline(message):
    """Extract airline from user message"""
    message = message.lower()
    
    for airline_key, airline_data in AIRLINES.items():
        if airline_key in message or airline_data["name"].lower() in message or airline_data["code"].lower() in message:
            return airline_data["name"], airline_data["code"]
    
    return None, None

def extract_airport(message):
    """Extract airport from user message"""
    message = message.lower()
    
    # Try to match IATA code first
    for iata, airport_data in INDIAN_AIRPORTS.items():
        if iata.lower() in message:
            return airport_data["name"], iata
    
    # Try to match city or airport name
    for iata, airport_data in INDIAN_AIRPORTS.items():
        if airport_data["city"].lower() in message or airport_data["name"].lower() in message:
            return airport_data["name"], iata
            
    # Use fuzzy matching for more complex cases
    airport = get_airport_by_name(message)
    if airport:
        return airport["name"], airport["iata"]
    
    return None, None

def extract_age(message):
    """Extract age from user message"""
    # Look for numbers in the message
    age_match = re.search(r'\b(\d+)\b', message)
    if age_match:
        age = int(age_match.group(1))
        if 1 <= age <= 120:  # Reasonable age range
            return age
    
    return None

def extract_date(message):
    """Extract date from user message"""
    message = message.lower()
    
    # Try to match common date formats
    # DD/MM/YYYY or DD-MM-YYYY or DD.MM.YYYY
    date_match = re.search(r'(\d{1,2})[/\-\.](\d{1,2})[/\-\.](\d{4}|\d{2})', message)
    if date_match:
        day, month, year = date_match.groups()
        # Handle 2-digit year (20xx) 
        if len(year) == 2:
            year = f"20{year}"
        
        try:
            travel_date = datetime(int(year), int(month), int(day))
            # Check if date is in the future
            if travel_date > datetime.now():
                return travel_date.strftime("%Y-%m-%d")
        except ValueError:
            pass
    
    # Try natural language date expressions
    today = datetime.now()
    
    if "today" in message:
        return today.strftime("%Y-%m-%d")
    elif "tomorrow" in message:
        travel_date = today + timedelta(days=1)
        return travel_date.strftime("%Y-%m-%d")
    elif "next week" in message:
        travel_date = today + timedelta(days=7)
        return travel_date.strftime("%Y-%m-%d")
    elif "next month" in message:
        # Add roughly 30 days
        travel_date = today + timedelta(days=30)
        return travel_date.strftime("%Y-%m-%d")
    
    # Check for month names
    months = {
        "january": 1, "february": 2, "march": 3, "april": 4, "may": 5, "june": 6,
        "july": 7, "august": 8, "september": 9, "october": 10, "november": 11, "december": 12,
        "jan": 1, "feb": 2, "mar": 3, "apr": 4, "jun": 6, "jul": 7, "aug": 8,
        "sep": 9, "sept": 9, "oct": 10, "nov": 11, "dec": 12
    }
    
    for month_name, month_num in months.items():
        if month_name in message:
            # Look for a day number near the month name
            day_match = re.search(r'(\d{1,2})(?:st|nd|rd|th)?\s+(?:of\s+)?' + month_name, message) or \
                        re.search(month_name + r'\s+(\d{1,2})(?:st|nd|rd|th)?', message)
            
            if day_match:
                day = int(day_match.group(1))
                year = today.year
                
                # If mentioned month is before current month, assume next year
                if month_num < today.month:
                    year += 1
                
                try:
                    travel_date = datetime(year, month_num, day)
                    return travel_date.strftime("%Y-%m-%d")
                except ValueError:
                    pass
    
    return None

def extract_travel_class(message):
    """Extract travel class from user message"""
    message = message.lower()
    
    if "business" in message:
        return "Business"
    elif "economy" in message or "eco" in message:
        return "Economy"
    elif "first" in message:
        return "First Class"
    elif "premium" in message:
        return "Premium Economy"
    
    return None

def process_user_input(user_message, current_state, session_data):
    """Process user input based on current conversation state"""
    response = {"message": ""}
    new_state = current_state
    updated_data = session_data.copy() if session_data else {}
    
    # Check for irrelevant input that's not related to flight booking
    flight_related_terms = ["flight", "book", "airline", "travel", "trip", "airplane", "ticket", "sky", 
                           "airport", "jet", "yes", "no", "ok", "okay", "sure", "departure", "arrival",
                           "destination", "from", "to", "date", "time", "class", "economy", "business",
                           "premium", "first", "age", "passenger", "air", "india", "indigo", "spicejet",
                           "vistara", "go", "confirm", "cancel", "price", "cost", "fare", "delhi", "mumbai",
                           "bangalore", "chennai", "kolkata", "hyderabad", "number", "seat", "baggage"]
    
    # Check for greetings in any state
    greeting_words = ["hi", "hello", "hey", "greetings", "howdy"]
    if any(word == user_message.lower().strip() for word in greeting_words):
        response["message"] = "Hi there! How can I help you with your flight booking today?"
        return response, current_state, updated_data
    
    # Check for irrelevant inputs (except in greeting state where we're more lenient)
    if current_state != "greeting" and len(user_message.strip()) > 3:
        if not any(term in user_message.lower() for term in flight_related_terms):
            response["message"] = "Sorry, I can't understand your request. I'm an airline booking assistant that can help you book flights, check schedules, and answer flight-related questions."
            return response, current_state, updated_data
    
    # State-specific processing
    if current_state == "greeting":
        if any(word in user_message.lower() for word in ["yes", "start", "book", "flight", "ticket"]):
            response["message"] = "Great! Let's book your flight. Which airline would you prefer? (e.g., IndiGo, Air India, SpiceJet)"
            new_state = STATE_TRANSITIONS[current_state]
        else:
            # Check for irrelevant questions
            flight_related_terms = ["flight", "book", "airline", "travel", "trip", "airplane", "ticket", "sky", "airport", "jet"]
            if not any(term in user_message.lower() for term in flight_related_terms):
                response["message"] = "Sorry, I can't understand your request. I'm an airline booking assistant. Can I help you book a flight?"
            else:
                response["message"] = "I'm here to help you book a flight. Would you like to start booking?"
    
    elif current_state == "airline":
        airline_name, airline_code = extract_airline(user_message)
        
        if airline_name:
            updated_data["airline"] = airline_name
            updated_data["airline_code"] = airline_code
            response["message"] = f"Great! You've selected {airline_name}. What's your departure city?"
            new_state = STATE_TRANSITIONS[current_state]
        else:
            # If user enters something else, default to IndiGo
            updated_data["airline"] = "IndiGo"
            updated_data["airline_code"] = "6E"
            response["message"] = "I'll set IndiGo as your airline. What's your departure city? (e.g., Delhi, Mumbai, Bangalore)"
            new_state = STATE_TRANSITIONS[current_state]
    
    elif current_state == "departure":
        departure_city, departure_iata = extract_airport(user_message)
        
        if departure_city and departure_iata:
            updated_data["departure_city"] = departure_city
            updated_data["departure_iata"] = departure_iata
            response["message"] = f"Flying from {departure_city}. What's your destination city?"
            new_state = STATE_TRANSITIONS[current_state]
        else:
            response["message"] = "I couldn't recognize that city. Please enter a major Indian city like Delhi, Mumbai, or Bangalore."
    
    elif current_state == "destination":
        destination_city, destination_iata = extract_airport(user_message)
        
        if destination_city and destination_iata:
            # Check that it's not the same as departure
            if "departure_iata" in updated_data and updated_data["departure_iata"] == destination_iata:
                response["message"] = "The destination can't be the same as the departure. Please choose a different city."
            else:
                updated_data["destination_city"] = destination_city
                updated_data["destination_iata"] = destination_iata
                response["message"] = f"Great! Flying to {destination_city}. When would you like to travel? (e.g., DD/MM/YYYY, tomorrow, next week, June 15)"
                new_state = STATE_TRANSITIONS[current_state]
        else:
            response["message"] = "I couldn't recognize that city. Please enter a major Indian city like Delhi, Mumbai, or Bangalore."
    
    elif current_state == "date":
        travel_date = extract_date(user_message)
        
        if travel_date:
            updated_data["travel_date"] = travel_date
            response["message"] = f"Flight date set to {travel_date}. What's your age?"
            new_state = STATE_TRANSITIONS[current_state]
        else:
            response["message"] = "I couldn't understand the date. Please provide a date in DD/MM/YYYY format or use phrases like 'tomorrow', 'next week', etc."
    
    elif current_state == "age":
        age = extract_age(user_message)
        
        if age:
            updated_data["age"] = age
            response["message"] = f"Thanks! And which travel class would you prefer? (Economy or Business)"
            new_state = STATE_TRANSITIONS[current_state]
        else:
            response["message"] = "Please enter a valid age as a number."
    
    elif current_state == "travel_class":
        travel_class = extract_travel_class(user_message)
        
        if travel_class:
            updated_data["travel_class"] = travel_class
            response["message"] = "Searching for flights... This might take a moment."
            new_state = STATE_TRANSITIONS[current_state]
        else:
            # Default to economy class
            updated_data["travel_class"] = "Economy"
            response["message"] = "I'll set Economy as your travel class. Searching for flights... This might take a moment."
            new_state = STATE_TRANSITIONS[current_state]
    
    elif current_state == "search_flights":
        try:
            # Try to get real flights from API
            flights = get_flights(updated_data["departure_iata"], updated_data["destination_iata"])
            flights_found = []
            
            if flights and flights.get("data") and len(flights["data"]) > 0:
                # Use real flight data
                for i, flight_data in enumerate(flights["data"][:3]):  # Get up to 3 flights
                    flight_time = datetime.fromisoformat(flight_data["departure"]["scheduled"].replace("Z", "+00:00"))
                    arrival_time = datetime.fromisoformat(flight_data["arrival"]["scheduled"].replace("Z", "+00:00"))
                    
                    flight_number = flight_data["flight"]["iata"]
                    # Generate price based on class
                    base_price = random.randint(3000, 7000)
                    if updated_data.get("travel_class") == "Business":
                        flight_price = base_price * 3
                    else:
                        flight_price = base_price
                    
                    flights_found.append({
                        "id": i + 1,
                        "flight_number": flight_number,
                        "departure_time": flight_time,
                        "arrival_time": arrival_time,
                        "price": flight_price
                    })
            
            # If no real flights were found or fewer than 3, add mock flights
            if len(flights_found) < 3:
                logging.warning(f"Adding mock flight data, only {len(flights_found)} real flights found")
                
                # How many mock flights to add
                mock_count = 3 - len(flights_found)
                
                for i in range(mock_count):
                    # Generate a realistic flight number
                    airline_code = updated_data.get("airline_code", "6E")
                    flight_number = f"{airline_code}-{random.randint(100, 999)}"
                    
                    # Generate realistic departure and arrival times
                    now = datetime.now()
                    
                    # Try to use the travel_date if provided, otherwise use random date
                    if updated_data.get("travel_date"):
                        try:
                            departure_date = datetime.strptime(updated_data["travel_date"], "%Y-%m-%d")
                        except:
                            departure_date = now + timedelta(days=random.randint(1, 30))
                    else:
                        departure_date = now + timedelta(days=random.randint(1, 30))
                    
                    departure_hour = random.randint(6, 22)
                    departure_minute = random.choice([0, 15, 30, 45])
                    departure_time = departure_date.replace(hour=departure_hour, minute=departure_minute, second=0, microsecond=0)
                    
                    # Flight duration between 1-3 hours for domestic Indian flights
                    flight_duration = timedelta(hours=random.randint(1, 3), minutes=random.randint(0, 59))
                    arrival_time = departure_time + flight_duration
                    
                    # Generate a realistic price based on class
                    base_price = random.randint(3000, 7000)  # Base economy price
                    if updated_data.get("travel_class") == "Business":
                        flight_price = base_price * 3
                    else:
                        flight_price = base_price
                    
                    flights_found.append({
                        "id": len(flights_found) + 1,
                        "flight_number": flight_number,
                        "departure_time": departure_time,
                        "arrival_time": arrival_time,
                        "price": flight_price
                    })
            
            # Select the first flight by default
            selected_flight = flights_found[0]
            
            # Update session data with selected flight details
            updated_data["flight_number"] = selected_flight["flight_number"]
            updated_data["departure_time"] = selected_flight["departure_time"].isoformat()
            updated_data["arrival_time"] = selected_flight["arrival_time"].isoformat()
            updated_data["price"] = selected_flight["price"]
            
            # Format the flights as plain text for the chat window
            message_text = f"I found {len(flights_found)} flights from {updated_data['departure_city']} to {updated_data['destination_city']} on {updated_data.get('travel_date', 'your selected date')}.\n\n"
            
            message_text += "Available Flights:\n"
            
            for flight in flights_found:
                message_text += f"• {updated_data['airline']} {flight['flight_number']}: {flight['departure_time'].strftime('%I:%M %p')} - {flight['arrival_time'].strftime('%I:%M %p')}, {updated_data.get('travel_class', 'Economy')}, Price: ₹{flight['price']}\n"
            
            message_text += f"\nThe following flight has been selected for you:\n{updated_data['airline']} {selected_flight['flight_number']}, Departure: {selected_flight['departure_time'].strftime('%I:%M %p')}, Price: ₹{selected_flight['price']}.\n\nWould you like to confirm this booking? (Yes/No)"
            
            response["message"] = message_text
            
            new_state = STATE_TRANSITIONS[current_state]
            
        except Exception as e:
            logging.error(f"Error searching for flights: {str(e)}")
            response["message"] = "I'm having trouble finding flights right now. Would you like to try again later?"
    
    elif current_state == "confirm_booking":
        if any(word in user_message.lower() for word in ["yes", "confirm", "book", "ok", "sure", "proceed"]):
            updated_data["confirmed"] = True
            
            # Generate random seat number
            seat_row = random.randint(1, 30)
            seat_col = random.choice(["A", "B", "C", "D", "E", "F"])
            seat_number = f"{seat_row}{seat_col}"
            updated_data["seat_number"] = seat_number
            
            # Format a detailed confirmation message
            thank_you_message = (
                f"🎟️ Booking Confirmed! Your ticket is being generated.\n\n"
                f"Thank you for booking with us! Your seat number is {seat_number}.\n"
                f"We hope you have a safe and pleasant journey on {updated_data.get('travel_date')}.\n\n"
                f"You can download your ticket below."
            )
            response["message"] = thank_you_message
            new_state = STATE_TRANSITIONS[current_state]
        else:
            updated_data["confirmed"] = False
            response["message"] = "Booking cancelled. Would you like to start a new search?"
            new_state = "greeting"
    
    elif current_state == "booking_complete":
        response["message"] = "Is there anything else I can help you with? You can start a new booking by saying 'book a flight'."
        new_state = "greeting"
    
    return response, new_state, updated_data
