import os
import logging
from datetime import datetime
from flask import render_template

# Configure logging
logging.basicConfig(level=logging.DEBUG)

def generate_ticket(booking, user):
    """
    Generate a ticket for a booking
    
    Args:
        booking: Booking object with flight details
        user: User object with passenger details
        
    Returns:
        str: HTML ticket that can be rendered or saved
    """
    try:
        # Format ticket data
        ticket_data = {
            'booking_reference': booking.booking_reference,
            'airline': booking.airline,
            'flight_number': booking.flight_number,
            'departure_city': booking.departure_city,
            'departure_iata': booking.departure_iata,
            'departure_time': booking.departure_time,
            'destination_city': booking.destination_city,
            'destination_iata': booking.destination_iata,
            'arrival_time': booking.arrival_time,
            'passenger_name': f"{user.first_name} {user.last_name}",
            'passenger_age': booking.passenger_age,
            'passenger_email': user.email,
            'travel_class': booking.travel_class,
            'price': booking.price,
            'status': booking.status,
            'issue_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        
        logging.info(f"Generated ticket for booking {booking.booking_reference}")
        
        return ticket_data
        
    except Exception as e:
        logging.error(f"Error generating ticket: {str(e)}")
        return None
