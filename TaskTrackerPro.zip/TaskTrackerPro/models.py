from datetime import datetime
from app import db
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(64), nullable=False)
    last_name = db.Column(db.String(64), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    bookings = db.relationship('Booking', backref='user', lazy=True)
    created_at = db.Column(db.DateTime, default=datetime.now)
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def __repr__(self):
        return f'<User {self.email}>'

class Booking(db.Model):
    __tablename__ = 'bookings'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    airline = db.Column(db.String(100), nullable=False)
    flight_number = db.Column(db.String(20), nullable=False)
    departure_city = db.Column(db.String(100), nullable=False)
    departure_iata = db.Column(db.String(3), nullable=False)
    destination_city = db.Column(db.String(100), nullable=False)
    destination_iata = db.Column(db.String(3), nullable=False)
    travel_date = db.Column(db.String(20), nullable=True)
    departure_time = db.Column(db.DateTime, nullable=False)
    arrival_time = db.Column(db.DateTime, nullable=False)
    passenger_age = db.Column(db.Integer, nullable=False)
    travel_class = db.Column(db.String(20), nullable=False)
    price = db.Column(db.Float, nullable=False)
    booking_reference = db.Column(db.String(10), nullable=False, unique=True)
    seat_number = db.Column(db.String(10), nullable=True)
    status = db.Column(db.String(20), default="Confirmed", nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.now)
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)

    def __repr__(self):
        return f'<Booking {self.booking_reference}>'

class ChatSession(db.Model):
    __tablename__ = 'chat_sessions'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    session_id = db.Column(db.String(50), nullable=False, unique=True)
    data = db.Column(db.JSON, nullable=True)  # Store session data like flight details
    state = db.Column(db.String(50), default="greeting")  # Current state in the conversation flow
    created_at = db.Column(db.DateTime, default=datetime.now)
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)

    def __repr__(self):
        return f'<ChatSession {self.session_id}>'
